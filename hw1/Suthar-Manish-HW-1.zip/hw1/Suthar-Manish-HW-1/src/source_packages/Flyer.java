package source_packages;

public interface Flyer {
	
	void fly();

}
